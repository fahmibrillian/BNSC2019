<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_score
 * @property int $id_game
 * @property int $id_user
 * @property int $score
 * @property Game $game
 * @property User $user
 */
class Score extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'score';

    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_score';

    /**
     * @var array
     */
    protected $fillable = ['id_game', 'id_user', 'score'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function game()
    {
        return $this->belongsTo('App\Game', 'id_game', 'id_game');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\User', 'id_user', 'id_user');
    }
}
