<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_game
 * @property string $nama_game
 * @property Score[] $scores
 */
class Game extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'game';

    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_game';

    /**
     * @var array
     */
    protected $fillable = ['nama_game'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function scores()
    {
        return $this->hasMany('App\Score', 'id_game', 'id_game');
    }
}
