<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;
class UserController extends Controller
{
    public function users(User $user){
    	$users = $user->all();
		return response()->json($users);
    }

    public function profile(){
    	$user = \App\User::find(Auth::user()->id_user);

    	return response()->json($user,200);
    }

	public function update(Request $request){
		$user = \App\User::find(Auth::user()->id_user);
		$user->fill($request->all());
		$user->save();
		return response()->json($user,200);
	}
}
