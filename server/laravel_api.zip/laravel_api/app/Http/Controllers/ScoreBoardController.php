<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;
class ScoreBoardController extends Controller
{
	public function insertScore(Request $request){
		$this->validate($request,[
			'id_game' => 'required',
			'score' => 'required',
		]);

		$score = new \App\Score;
		$score->fill($request->all());
		$score->id_user = Auth::user()->id_user;
		$score->save();
		return response()->json($score,200);
	}

	public function getLeaderBoard(Request $request){
		$score = \App\Score::orderBy('score','desc')->take(10)->where('id_game','=',$request->id_game)->get();
		return response()->json($score,200);
	}
}
