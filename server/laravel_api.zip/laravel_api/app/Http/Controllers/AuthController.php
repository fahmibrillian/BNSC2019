<?php

namespace App\Http\Controllers;

use http\Env\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function register(Request $request){
    	$this->validate($request,[
    		'name' => 'required',
		    'email' => 'required|email|unique:users',
		    'password' => 'required|min:6',
		    'username' => 'required|min:6',
		    'tanggal_lahir' => 'required|date',
		    'no_hp' => 'required'
	    ]);

    	$user = \App\User::create([
    		'name' => $request->name,
		    'username' => $request->username,
		    'email' => $request->email,
		    'password' => bcrypt($request->password),
		    'tanggal_lahir' => $request->tanggal_lahir,
		    'no_hp' => $request->no_hp,
		    'url_foto' => @$request->url_foto,
		    'token' => bcrypt($request->name)
	    ]);

    	return response()->json($user,201);
    }

    public function login(Request $request){
    	if(!Auth::attempt(['email' => $request->email,'password'=>$request->password])){
    		return response()->json(['message'=>'Your Credintial is Wrong'],401);
	    }

	    $user = \App\User::find(Auth::user()->id_user);

    	return response()->json($user,200);
    }
}
